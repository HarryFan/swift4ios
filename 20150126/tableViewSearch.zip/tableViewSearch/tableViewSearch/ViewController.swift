


//
//  ViewController.swift
//  tableViewSearch
//
//  Created by h2 on 2015/1/23.
//  Copyright (c) 2015年 h2. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    let sectionsTableIdentifier = "SectionTableIndentifier";
    var names:[String:[String]]!;
    var keys: [String]!;
    var searchController: UISearchController!;
    @IBOutlet weak var tableView: UITableView!;
    override func viewDidLoad() {
        super.viewDidLoad()
        var plistPath = NSBundle.mainBundle().pathForResource("sortednames", ofType: "plist")!;
        //var objectiveCNames: NSDictionary = NSDictionary(contentsOfFile: plistPath)!;
        names = NSDictionary(contentsOfFile: plistPath) as [String: [String]];
        keys = (names as NSDictionary).allKeys as [String];
        keys.sort(){$0 < $1};
        
        
        //register cell prototype
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: sectionsTableIdentifier);
        
        //tableIndex
        tableView.sectionIndexColor = UIColor.whiteColor();
        tableView.sectionIndexBackgroundColor = UIColor.blackColor();
        tableView.sectionIndexTrackingBackgroundColor = UIColor.darkGrayColor();
        
        //created searchContorller
        let resultsContorller = ResultViewController();
        resultsContorller.names = names;
        resultsContorller.keys = keys;
        searchController = UISearchController(searchResultsController: resultsContorller);
        
        //display searchContoller's searchBar
        let searchBar = searchController.searchBar;
        searchBar.scopeButtonTitles = ["All", "Short", "Long"];
        searchBar.placeholder = "Enter a search term";
        searchBar.sizeToFit();
        tableView.tableHeaderView = searchBar;
        searchController.searchResultsUpdater = resultsContorller;
    }
    
    //UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int{
        return keys.count;
    }
    
    func tableView(tableView: UITableView,
        numberOfRowsInSection section: Int) -> Int{
            let key = keys[section];
            let nameSection:[String]? = names[key];
            
            return nameSection!.count;
    }
    
    func tableView(tableView: UITableView,
        cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
            let cell = tableView.dequeueReusableCellWithIdentifier(sectionsTableIdentifier, forIndexPath: indexPath) as UITableViewCell;
            let key = keys[indexPath.section];
            let nameSection = names[key];
            let name = nameSection![indexPath.row];
            
            cell.textLabel.text = name;
            return cell;
    }
    
    
    func tableView(tableView: UITableView,
        titleForHeaderInSection section: Int) -> String?{
            return keys[section];
    }
    
    func sectionIndexTitlesForTableView(tableView: UITableView) -> [AnyObject]!{
        return keys;
    }
    
    //UITableViewDelegate
    
}


