//
//  ResultViewController.swift
//  tableViewSearch
//
//  Created by h2 on 2015/1/26.
//  Copyright (c) 2015年 h2. All rights reserved.
//

import UIKit

class ResultViewController: UITableViewController,UISearchResultsUpdating {
    let sectionsTableIndentifier = "SectionsTableIndentifier";
    var names:[String:[String]] = [String:[String]]();
    var keys:[String] = [String]();
    var filterNames:[String] = [String]();
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.backgroundColor = UIColor.lightGrayColor();
        
        self.tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: sectionsTableIndentifier);
    }
    
    //UISearchResultsUpdating
    func updateSearchResultsForSearchController(searchController: UISearchController){
        let searchString = searchController.searchBar.text;
        let buttonIndex = searchController.searchBar.selectedScopeButtonIndex;
        filterNames.removeAll(keepCapacity: true);
        if !searchString.isEmpty{
            let filter:(String) -> Bool = {
                name in
                let range = name.rangeOfString(searchString, options: .CaseInsensitiveSearch);
                return range != nil;
            }
            
            for key in keys{
                let namesForKey = names[key];
                let matches = namesForKey!.filter(filter);
                filterNames += matches;
            }
        }
        
        self.tableView.reloadData();
    }
    
    
    //UITableViewDataSource
    override func tableView(tableView: UITableView,
        numberOfRowsInSection section: Int) -> Int{
            return filterNames.count;
    }
    
    override func tableView(tableView: UITableView,
        cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
            let cell = tableView.dequeueReusableCellWithIdentifier(sectionsTableIndentifier, forIndexPath: indexPath) as UITableViewCell;
            let name = filterNames[indexPath.row];
            cell.textLabel.text = name;
            return cell;
    }
}
